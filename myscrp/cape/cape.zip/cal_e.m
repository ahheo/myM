function e=cal_e(t)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% **Tetens Empirical Formula**
% THIS FUNCTION CALCULATES VAPOR PRESSURE OR SATURATED VAPOR PRESSURE
% INPUT
% t: Temprature/Dew point (Celsius Degree)
% OUTPUT
% e: Saturated Vapor Pressure/Vapor Pressure (hPa)
%
% +++++  linchg@itpcas.ac.cn  +++++
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

l=length(t);

e(1:l,1)=nan;

if t>=0
    a=7.5; b=237.3; %WATER SUFACE
else
    a=9.5; b=265.5; %ICE SUFACE
end

A=t>-150&t<60;
e(A)=6.112*10.^(a*t(A)./(b+t(A)));

end